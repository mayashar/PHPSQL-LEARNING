https://in-info-web4.informatics.iupui.edu/~mayshar/flashcard.php
READ ME:

Setting Local Server Xampp Steps:

Download and install Xampp

Open Control Panel of Xampp

Start Service apache and mysql

Type localhost in the browser 

go to phpmyadmin

create a database mayashar_db in my case

STATE.sql is imported 

create page for database connection

CSS and Scripts applied accordingly 







