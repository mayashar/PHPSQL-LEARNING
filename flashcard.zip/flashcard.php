
  
<style>

	.card{
	

  border-radius: 5px;
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
  transition: 0.3s;
  width: 30%;
  height: :100%;
  margin-top: 40;
  margin-left: 20%;
  margin-right: 60%;
  background: orange;
  
}
</style>

  <div class="card"> 

<?php

include 'dbconnection.php';


$stateid = rand(1, 53);




$page = $_SERVER['PHP_SELF'];
print "<a href=\"$page\">CLICK AND ENJOY STATE FLASHCARDS</a>";


$html = '<html><head><style>

 p {
	 
  border: 1px solid red;
  margin-left:10;
  font-size:24;
  width: 90%;
  height:10%;
  box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.5);
  padding: 4px 4px;
  
} 



</style></head><body>';


$sql = "SELECT STATE_ABBR, STATE, CAPITOL, NUM_REPS FROM STATES WHERE ID = '".$stateid."'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
  
    while($row = mysqli_fetch_assoc($result)) {

   $html = $html.'<p = "class">'.$row['STATE_ABBR'].'</p>';
         $html = $html.'<p = "class">'.$row['STATE'].'</p>';
       	 $html = $html.'<p = "class">'.$row['CAPITOL'].'</p>';
         $html = $html.'<p = "class">'.$row['NUM_REPS'].'</p>';
        


        }
        							
    
    $html = $html."</body></html>";
    echo $html;
} else {
    echo "0 results";
}

mysqli_close($conn);

?></div>