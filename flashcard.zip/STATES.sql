-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 04, 2020 at 05:17 PM
-- Server version: 10.2.27-MariaDB-10.2.27+maria~xenial
-- PHP Version: 7.0.33-0ubuntu0.16.04.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aqumarti_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `STATES`
--

CREATE TABLE `STATES` (
  `ID` varchar(2) DEFAULT NULL,
  `STATE_ABBR` varchar(10) DEFAULT NULL,
  `STATE` varchar(24) DEFAULT NULL,
  `CAPITOL` varchar(22) DEFAULT NULL,
  `NUM_REPS` varchar(8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `STATES`
--

INSERT INTO `STATES` (`ID`, `STATE_ABBR`, `STATE`, `CAPITOL`, `NUM_REPS`) VALUES
('1', 'AL  ', 'Alabama', '"Montgomery"', '7'),
('2', 'AK  ', 'Alaska', '"Juneau"', '1'),
('3', 'AZ  ', 'Arizona', '"Phoenix"', '9'),
('4', 'AR  ', 'Arkansas', '"Little Rock"', '4'),
('5', 'CA  ', 'California', '"Sacramento"', '53'),
('6', 'CO  ', 'Colorado', '"Denver"', '7'),
('7', 'CT  ', 'Connecticut', '"Hartford"', '5'),
('8', 'DC  ', 'Delaware', '"District of Columbia"', '1'),
('9', 'DE  ', 'District of Columbia', '"Dover"', '0'),
('10', 'FL  ', 'Florida', '"Tallahassee"', '27'),
('11', 'GA  ', 'Georgia', '"Atlanta"', '14'),
('12', 'HI  ', 'Hawaii', '"Honolulu"', '2'),
('13', 'ID  ', 'Idaho', '"Boise"', '2'),
('14', 'IL  ', 'Illinois', '"Springfield"', '18'),
('15', 'IN  ', 'Indiana', '"Indianapolis"', '9'),
('16', 'IA  ', 'Iowa', '"Des Moines"', '4'),
('17', 'KS  ', 'Kansas', '"Topeka"', '4'),
('18', 'KY  ', 'Kentucky', '"Frankfort"', '6'),
('19', 'LA  ', 'Louisiana', '"Baton Rouge"', '6'),
('20', 'ME  ', 'Maine', '"Augusta"', '2'),
('21', 'MD  ', 'Maryland', '"Annapolis"', '8'),
('22', 'MA  ', 'Massachusetts', '"Boston"', '9'),
('23', 'MI  ', 'Michigan', '"Lansing"', '14'),
('24', 'MN  ', 'Minnesota', '"St Paul"', '8'),
('25', 'MS  ', 'Mississippi', '"Jackson"', '4'),
('26', 'MO  ', 'Missouri', '"Jefferson City"', '8'),
('27', 'MT  ', 'Montana', '"Helena"', '1'),
('28', 'NE  ', 'Nebraska', '"Lincoln"', '3'),
('29', 'NV  ', 'Nevada', '"Carson City"', '4'),
('30', 'NH  ', 'New Hampshire', '"Concord"', '2'),
('31', 'NJ  ', 'New Jersey', '"Trenton"', '12'),
('32', 'NM  ', 'New Mexico', '"Santa Fe"', '3'),
('33', 'NY  ', 'New York', '"Albany"', '27'),
('34', 'NC  ', 'North Carolina', '"Raleigh"', '13'),
('35', 'ND  ', 'North Dakota', '"Bismarck"', '1'),
('36', 'OH  ', 'Ohio', '"Columbus"', '16'),
('37', 'OK  ', 'Oklahoma', '"Oklahoma City"', '5'),
('38', 'OR  ', 'Oregon', '"Salem"', '5'),
('39', 'PA  ', 'Pennsylvania', '"Harrisburg"', '18'),
('40', 'PR  ', 'Puerto Rico', '"San Juan"', '0'),
('41', 'RI  ', 'Rhode Island', '"Providence"', '2'),
('42', 'SC  ', 'South Carolina', '"Columbia"', '7'),
('43', 'SD  ', 'South Dakota', '"Pierre"', '1'),
('44', 'TN  ', 'Tennessee', '"Nashville"', '9'),
('45', 'TX  ', 'Texas', '"Austin"', '36'),
('46', 'US  ', 'United States of America', '"District of Columbia"', '35'),
('47', 'UT  ', 'Utah', '"Salt Lake City"', '4'),
('48', 'VT  ', 'Vermont', '"Montpelier"', '1'),
('49', 'VA  ', 'Virginia', '"Richmond"', '11'),
('50', 'WA  ', 'Washington', '"Olympia"', '10'),
('51', 'WV  ', 'West Virginia', '"Charleston"', '3'),
('52', 'WI  ', 'Wisconsin', '"Madison"', '8'),
('53', 'WY  ', 'Wyoming', '"Cheyenne"', '1');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
