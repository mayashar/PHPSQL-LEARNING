<!DOCTYPE html>
<html>
<head>
<style>
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
</style>
</head>
<body>
<?php
	include 'dbconnection.php';

	$sql = "select id ,name , description ,qty,category,unitprice, unitprice* 0.07 + unitprice as price_with_tax from books";

	//$sql = "select * from books";
		$result = mysqli_query($conn, $sql);
	if (mysqli_num_rows($result) > 0) {
		 echo "<table><tr><th>Book ID</th><th>Name</th><th>Description</th><th>Price</th><th>Price w/Tax</th></tr>";
	    // output data of each row
	    while($row = mysqli_fetch_assoc($result)) {
	    	//$price_tax = ( $price *  $tax ) + $price;
					echo "<tr><td>" . $row["id"]. "</td><td>" . $row["name"]. "</td><td> " . $row["description"]."</td><td>".'$'. $row["unitprice"]."</td><td>".'$'. $row["price_with_tax"]."</td></tr>";
	    }
	     echo "</table>";
	} else {
	    echo "No results";
	}
	mysqli_close($conn);

?>
</body>
</html>