
<?php
	
	include 'dbconnection.php';

	$sql = "select * from books";
		$result = mysqli_query($conn, $sql);
	if (mysqli_num_rows($result) > 0) {
	    // output data of each row
	    while($row = mysqli_fetch_assoc($result)) {
	    	$price_tax = ( $price * $tax) + $price;
			$my_var=$my_var.$row['id']."*".$row['name']."*". $row['description']."*".$row['unitprice']."*".$row['qty']."*".$row['category']."<br>";
	    }
	    echo $my_var;
	} else {
	    echo "No results";
	}
	mysqli_close($conn);

?>
