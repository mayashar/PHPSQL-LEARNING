READ ME:

Setting Local Server Xampp Steps:

Download and install Xampp

Open Control Panel of Xampp

Start Service apache and mysql

Type localhost in the browser 

go to phpmyadmin

create a database

create table required

create page for database connection

create other pages as required and connect to the database by including database connection file

work on accordingly using php and html 


USER ID AND PASSWORD

id = user@demo.com
pwd= admin

ADMIN ID AND PASSWORD
id= maya@demo.com
pwd=1234






