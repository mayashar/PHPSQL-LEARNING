<?php


?>

<html>

<head>
    <title>Register</title>
</head>

<body>
    <br>
    <form action="register.php" method="post" name="form1">
        <table width="40%">
            <tr>
                <td>First Name</td>
                <td><input type="text" name="firstname" required></td>
            </tr>
            <tr>
                <td>Last Name</td>
                <td><input type="text" name="lastname" required></td>
            </tr>
            <tr>
                <td>Email</td>
                <td><input type="email" name="email" required></td>
            </tr>
            <td>Password</td>
            <td><input type="password" name="password" required></td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" name="register" value="Register"></td>
            </tr>
        </table>
        <a href="login.php">Login</a>

        <?php

        //include the database connection 

        include_once("dbconnection.php");

        // form submission by insert user information

        if (isset($_POST['register'])) {
            $fname     = $_POST['firstname'];
            $lname     = $_POST['lastname'];
            $email    = $_POST['email'];
            $password = $_POST['password'];

            // give error on email already there

            $email_result = mysqli_query($conn, "select 'email' from users where email='$email' and password='$password'");

            // Counting number of matched row

            $user_matched = mysqli_num_rows($email_result);

            // check if email already there

            if ($user_matched > 0) {
                echo "<br/><br/><strong>Error: </strong> User already exists with the email id '$email'.";
            } else {

                // Insert user data into database user table

                $result   = mysqli_query($conn, "INSERT INTO users(firstname,lastname,email,password) VALUES('$fname','$lname','$email','$password')");

                // check if any error

                if ($result) {
                    echo "<br/><br/>Registration successfull.";
                } else {
                    echo "Try again." . mysqli_error($conn);
                }
            }
        }

        ?>
    </form>
</body>

</html>