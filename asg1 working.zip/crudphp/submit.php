<?php
	
	include 'dbconnection.php';

	$fname=$_POST["firstname"];
	$lname=$_POST["lastname"];
	$email=$_POST["email"];
	$issue=$_POST["issue"];
	$submit=$_POST['submit'];
	
	//var_dump($fname,$lname,$email);


	$sql1="select max(id) as id from formtest";
	$result=mysqli_query($conn,$sql1);
	$row=mysqli_fetch_assoc($result);
	$newid=$row['id'] + 1;




	$sql2="insert into formtest
	(id,firstname,lastname,email,issue)
	values('$newid','$fname','$lname','$email','$issue')";



	if (mysqli_query($conn,$sql2)){
		echo "New record created successfully";
		header("location: result.php");
	} else{
		echo "Error:" .$sql2. "<br>" . mysqli_error($conn);
	
	}
	mysqli_close($conn);

?>
