<!DOCTYPE html>
<html >
<head>
<title>welcome page</title>

</head>
<body>

<div >

  <a href="index.php">Home</a>
  <a href="admin/login.php">Admin</a>
  <a href="login.php">User</a>
   
</div>



</body>
</html>
