<!DOCTYPE html>
<html>
<head>

<style>
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
</style>
</head>

<body>

<?php
	
	echo "IU IT Service ";

	include 'dbconnection.php';

$sql = "select * from formtest";
		$result = mysqli_query($conn, $sql);

	

		$result = mysqli_query($conn, $sql);
	if (mysqli_num_rows($result) > 0) {

		 echo "<table><tr><th>id</th><th>first name</th><th>last name</th><th>email</th><th>Issue</th><th>time</th><th>status</th></tr>";

	    // output data of each row

	    while($row = mysqli_fetch_assoc($result)) {

	    			
					echo 	"<tr><td>".  $row["id"]. 
							"</td><td>". $row["firstname"].
							"</td><td>". $row["lastname"].
							"</td><td>". $row["email"].
							"</td><td>". $row["issue"].
							"</td><td>". date(($row['time'])).
							 
							"</td><td>". $row["status"].
							"</td></tr>";
	    }
	     echo "</table>";
	} else {
	    echo "No results";
	}
	mysqli_close($conn);

?>
<div>
<a href="logout.php"> Logout</a>
</div>

</body>
</html>


 





