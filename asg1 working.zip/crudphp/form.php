<?php 
include 'dbconnection.php';

$sql="select * from formtest";
$rows=$conn->query($sql);

 ?>

<!DOCTYPE html>
<html>
  <head>
    <title>IU IT Service </title>

      
  </head>
  <body>
    
      <form action="submit.php" method="post">
      	First Name:<br>
      	<input type="text" name="firstname"><br>
      	Last Name:<br>
      	<input type="text" name="lastname"><br>
      	Email:<br>
      	<input type="text" name="email"><br>
      	Request:<br>
      	<textarea name="issue" >how can we help!!!</textarea>
      	<input type="submit" name="submit"><br>

        
      </form>
    </div>
  </body>
</html>