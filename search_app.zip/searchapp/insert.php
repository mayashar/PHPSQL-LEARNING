
<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "search_app";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$file = fopen('df_diseases.txt','r');

echo "<table border='1'>
    		<tr>
      		  <th> ID</th>
      		  <th>Name</th>
      		  <th>Link</th>
      		  <th>Symptoms</th>
                  <th>Causes</th>
                  <th>Risk Factor</th>
                  <th>Overview</th>
		  <th>Treatment</th>
                  <th>Medication</th>
                  <th>Home remedies</th>
 		 </tr>";
     
   	while (!feof($file))
          {
            $line = fgets($file);  
	    $delimiter = "\t";
            $tab = explode($delimiter, $line);
	    $pattern = array('"["','[',']','"]"',"'",'"','\n');
	    str_replace($pattern,"",$tab);
            
            $id = $tab[0];  
            $name = str_replace($pattern,"",$tab[1]);
            $link = str_replace($pattern,"",$tab[2]);
	    $symptoms = str_replace($pattern,"",$tab[3]);
	    $causes = str_replace($pattern,"",$tab[4]);
	    $risk_factor = str_replace($pattern,"",$tab[5]);
            $overview = str_replace($pattern,"",$tab[6]);
	    $treatment = str_replace($pattern,"",$tab[7]);
            $medication = str_replace($pattern,"",$tab[8]);
            $home_remedies = str_replace($pattern,"",$tab[9]);  
      
	   
	     echo "
        		<tr>
            			<td>".$id."</td>
            			<td>".$name."</td>
            			<td>".$link."</td>
            			<td>".$symptoms."</td>
                                <td>".$causes."</td>
                                <td>".$risk_factor."</td>
                                <td>".$overview."</td>
                                <td>".$treatment."</td>
                                <td>".$medication."</td>
				<td>".$home_remedies."</td>                                                                             
                                 
               		</tr>"; 
 
	    $sql = "insert into diseases(id,name,link,symptoms,causes,risk_factor,overview,treatment,medication,home_remedies) values ('$id','$name','$link','$symptoms','$causes','$risk_factor','$overview','$treatment','$medication','$home_remedies')";
 	    mysqli_query($conn, $sql);
	 	
	

	
       }
   echo "insertion into table done";
        
	fclose($file);  
	?>