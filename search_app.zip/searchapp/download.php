<?php

include 'dbconnection.php';
$file = fopen("data.txt","w+") or die ("Unable to Open the File");
$query = $_GET['name'];

#$mydata = "this is the data \n line1 \n line2 \n";

$sql = "SELECT * FROM diseases WHERE name = '".$query."'";

$raw_results = mysqli_query($conn, $sql);         
            
        if(mysqli_num_rows($raw_results) > 0){ // if one or more rows are returned do following
             
             #echo "Displaying results for ".$query. "<br>";
            while($results = mysqli_fetch_assoc($raw_results)){
                             
                $name = "Name:  ".$results['name']."\n\n";
                $overview = "Overview: ".$results['overview']."\n\n";
                $symptoms = "Symptoms: ".$results['symptoms']."\n\n";
                $causes = "Causes: ".$results['causes']."\n\n";
                $risks = "Risk Factors:".$results['risk_factor']."\n\n";
                $treatment ="Treatment: ".$results['treatment']."\n\n";
                $medication = "Medication: ".$results['medication']."\n\n";
                $homeremedies = "Home Remedies: ".$results['home_remedies']."\n\n";

                $link = "Reference Link: ".$results['link']."\n\n";
                
            }
             
        }

$mydata = $name.$overview.$symptoms.$causes.$risks.$treatment.$medication.$homeremedies.$link;

fwrite($file, $mydata);
fclose($file);


// example modified from code provided by http://php.net/manual/en/function.readfile.php
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="'.basename('data.txt').'"');
header('Expires: 0');
header('Cache-Control: must-revalidate');
header('Pragma: public');
header('Content-Length: ' . filesize('data.txt'));
readfile('data.txt');
exit;

?>