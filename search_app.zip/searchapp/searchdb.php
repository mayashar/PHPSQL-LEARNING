<!DOCTYPE html>
    <html>
    <head>
    	<title>Search</title>


    </head>
    	<script>
	function myFunction() {
  	alert("want to download");
	}
	</script>

    <body>
    <h2>Search disease here:</h2>

    <form action="searchdb.php" method="post">
    	<label >Search</label>
    	<input type="text"  name="search" placeholder="Search here..">
    	<input type="submit" name="submit" value="SEARCH">&nbsp &nbsp &nbsp &nbsp&nbsp &nbsp &nbsp &nbsp
    	
    	
    </form>



<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "search_app";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}




$result=" ";

 


if(isset($_POST['search'])){
	$searchq=$_POST['search'];
	$searchq=preg_replace("#[^0-9a-z]#i"," " , $searchq);
	$query =mysqli_query($conn,"SELECT * FROM diseases WHERE name LIKE '%$searchq%'") or die("db not found".mysql_error());
	$count=mysqli_num_rows($query);
	if ($count==0){

		$result="Nothing found";


	}else

	
	echo "<p><b>View result</b></p>";

	

	echo "<table border='1' cellpadding='10' >";


	echo "<tr> <th>ID</th> <th>Name</th> <th>Link</th> <th>Symptoms</th> <th>Causes</th>
	<th>Risk Factor</th> <th>Overview</th> <th>Treatment</th> <th>Medication</th> <th>Home Remedies</th>
	</tr>";



	{
		while($row=mysqli_fetch_array($query)){

			echo "<tr>";

			echo '<td>'. $row['id'] . '</td>';
				echo '<td><a href ="download.php?'.$row['name'].'">'.$row['name'].'</a></td>';
					echo '<td>' .$row['link']. '</td>';
						echo '<td>'  .$row['symptoms']. '</td>';
							echo '<td>' .$row['causes']. '</td>';
								echo '<td>' .$row['risk_factor'].'</td>';
									echo '<td>'.$row['overview'].'</td>';
									echo '<td>'.$row['treatment'].'</td>';
									echo '<td>'.$row['medication'].'</td>';
									echo '<td>'.$row['home_remedies'].'</td>';
									#echo '<td><a href ="download.php?'.$row['name'].'">'.$row['name'].'</a></td>';

			echo "</tr>";

}

		
}
echo "</table>";

}

print("$result");



?>

 
   
    
    
     
    </body>
    </html>

    

  

    