<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "search_app";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// sql to create table
$sql="CREATE TABLE diseases (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
name VARCHAR(150) NOT NULL,
link VARCHAR(150) NOT NULL,
symptoms VARCHAR(200) NOT NULL,
causes VARCHAR(200) NOT NULL,
risk_factor VARCHAR(200) NOT NULL,
overview VARCHAR(200) NOT NULL,
treatment VARCHAR(200) NOT NULL,
medication VARCHAR(200) NOT NULL,
home_remedies VARCHAR(200) NOT NULL
)";


if ($conn->query($sql) === TRUE) {
    echo "Table created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}


$conn->close();
?>